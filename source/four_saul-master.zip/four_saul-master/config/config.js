module.exports = {
    user: 'http://four.huahuayu.com.cn/srnswx/tbuser/insert',
    userUpdate: 'http://four.huahuayu.com.cn/srnswx/tbuser/update/',
    userLocation: 'http://four.huahuayu.com.cn/srnswx/tbuser/getbylo',
    userSearch: 'http://four.huahuayu.com.cn/srnswx/tbuser/getbyna?name=',
    shop: 'http://four.huahuayu.com.cn/srnswx/tbshop/insert',
    shopUpdate: 'http://four.huahuayu.com.cn/srnswx/tbshop/update/',
    shopLocation: 'http://four.huahuayu.com.cn/srnswx/tbshop/getbylo',
    userService: 'http://four.huahuayu.com.cn/srnswx/service/getall',
    shopService: 'http://four.huahuayu.com.cn/srnswx/service/getall',
    shopSearch: 'http://four.huahuayu.com.cn/srnswx/tbshop/getbyna?name=',
    detail: 'http://four.huahuayu.com.cn/srnswx/tbstaff/getdetail',
    industry: 'http://four.huahuayu.com.cn/srnswx/tbindustry/get',
    industryDetail: 'http://four.huahuayu.com.cn/srnswx/tbshop/getbyin/',
    getbyop: 'http://four.huahuayu.com.cn/srnswx/tbstaff/getbyop?openid=',
    check: 'http://four.huahuayu.com.cn/srnswx/tbstaff/checkstaff',
    login: 'http://four.huahuayu.com.cn/srnswx/tbstaff/checkstaff',
    weixin: 'http://four.huahuayu.com.cn/srnswx/jssdkconfig'
}